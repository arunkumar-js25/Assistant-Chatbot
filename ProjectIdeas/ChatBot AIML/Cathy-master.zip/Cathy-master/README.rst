Cathy AI Discord Chat Bot
=========================

Artificial intelligence (AI) chat bot for Discord written in Python


.. image:: https://readthedocs.org/projects/cathy-docs/badge/?version=latest
   :target: https://cathy-docs.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://badge.fury.io/py/cathy.svg
   :target: https://badge.fury.io/py/cathy
   :alt: Cathy on pypi

Documentation
=============

Read the documentation online at http://cathy-docs.rtfd.io/

Optionally, to build the documentation yourself from the ``docs/`` folder::

  pip install sphinx
  cd docs/
  make html


Source code
===========

https://github.com/DevDungeon/Cathy

Contact
=======

nanodano@devdungeon.com
