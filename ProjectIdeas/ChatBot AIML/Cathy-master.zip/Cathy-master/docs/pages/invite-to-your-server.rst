==================================
Invite existing bot to your server
==================================

Chatty Cathy is a public bot that you can invite Chatty Cathy to your own
Discord server. If you invite the public bot, you will need to create a channel
named "chat-with-cathy" to chat with the bot. This is done to prevent the chat
spam in every channel. If you want to customize the channel name you can run
your own instance of the bot. Instructions are below. To invite the public bot,
just visit this authorization URL directly:

Invite the bot
==============

To invite the exiting bot to your server and chat,
first invite the bot to your server and then
create a channel named ``#chat-with-cathy``.

Follow this link to invite the bot:

https://discordapp.com/oauth2/authorize?client_id=387435655925596160&scope=bot

Create the chat-with-cathy channel
==================================

Don't forget to create the ``#chat-with-cathy`` channel.
Talk in that channel.
