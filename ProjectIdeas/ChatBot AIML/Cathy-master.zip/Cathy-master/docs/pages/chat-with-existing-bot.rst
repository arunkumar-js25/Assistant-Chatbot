======================
Chat with existing bot
======================

You can join the DevDungeon.com Discord server and chat with the bot in the ``#chat-with-cathy`` channel.

Use this link to join the Discord server: https://discord.gg/unSddKm
