=====================
What is Cathy?
=====================

Cathy is an artificial intelligence (AI) chat bot for Discord server.
It written in Python 3 and is easily extended with new commands.
You can invite the DevDungeon Cathy to your server or run your own version.

The chat bot intelligence is powered by AIML.
It comes packaged by default with the Alice bot set of XML files.
You can also add your own AIML files to modify the chat behavior in the
`cathy/aiml/custom/` folder. You can follow these tutorials to learn more about
using AIML with Python:

- https://www.devdungeon.com/content/live-coding-discord-ai-chat-bots-python
- https://www.devdungeon.com/content/ai-chat-bot-python-aiml
